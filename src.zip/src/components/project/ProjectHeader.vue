<script setup>
import { onMounted, onBeforeUnmount, reactive, ref } from 'vue'

const props = defineProps({
  project: { type: Object, required: true },
  saving: { type: Boolean, default: false },
  error: { type: String, default: '' },
  mode: { type: String, default: 'edit' },
})
const emit = defineEmits(['close', 'save'])
const dialogo = ref(null)
const erroLocal = ref('')
const form = reactive({
  name: props.project.name || props.project.title || '',
  description: props.project.description || '',
  status: props.project.status || 'planned',
})
const statusConhecidos = ['planned', 'in_progress', 'paused', 'completed']

onMounted(() => dialogo.value?.showModal())
onBeforeUnmount(() => dialogo.value?.close())

function fechar() {
  if (!props.saving) emit('close')
}

function salvar() {
  if (props.saving) return
  erroLocal.value = ''
  if (!form.name.trim()) {
    erroLocal.value = 'Informe o nome do projeto.'
    return
  }
  emit('save', { name: form.name.trim(), description: form.description.trim(), status: form.status })
}
</script>

<template>
  <dialog ref="dialogo" class="edit-modal" :aria-label="mode === 'create' ? 'Criar projeto' : 'Editar projeto'" :aria-busy="saving" @cancel.prevent="fechar">
    <header class="edit-modal__header">
      <div><span>SEU ESPAÇO DE TRABALHO</span><h2>{{ mode === 'create' ? 'Novo projeto' : 'Editar projeto' }}</h2></div>
      <button type="button" class="close-button" aria-label="Fechar edição" :disabled="saving" @click="fechar">×</button>
    </header>
    <form @submit.prevent="salvar">
      <fieldset :disabled="saving">
        <label>Nome do projeto<input v-model="form.name" name="name" type="text" required autofocus /></label>
        <label>Descrição<textarea v-model="form.description" name="description" rows="5" placeholder="Descreva o objetivo do projeto"></textarea></label>
        <label>Status
          <select v-model="form.status" name="status">
            <option value="planned">Planejado</option>
            <option value="in_progress">Em andamento</option>
            <option value="paused">Pausado</option>
            <option value="completed">Concluído</option>
            <option v-if="!statusConhecidos.includes(form.status)" :value="form.status">{{ form.status }}</option>
          </select>
        </label>
      </fieldset>
      <p v-if="erroLocal || error" class="form-error" role="alert">{{ erroLocal || error }}</p>
      <footer>
        <button type="button" class="button" :disabled="saving" @click="fechar">Cancelar</button>
        <button type="submit" class="button button--primary" :disabled="saving">{{ saving ? 'Salvando...' : mode === 'create' ? 'Criar projeto' : 'Salvar alterações' }}</button>
      </footer>
    </form>
  </dialog>
</template>

<style scoped>
.edit-modal { position: fixed; inset: 0; width: min(560px, calc(100% - 32px)); max-height: calc(100dvh - 32px); margin: auto; padding: 0; overflow-y: auto; box-sizing: border-box; border: 1px solid #000; border-radius: 20px; background: #fff; color: #000; box-shadow: 0 24px 80px rgb(0 0 0 / 24%); }
.edit-modal::backdrop { background: rgb(0 0 0 / 65%); }
.edit-modal__header { display: flex; align-items: center; justify-content: space-between; gap: 16px; padding: 24px; border-bottom: 1px solid #000; }
.edit-modal__header span { font-size: 10px; font-weight: 700; letter-spacing: 1.5px; }
h2 { margin: 8px 0 0; font-size: 24px; font-weight: 700; letter-spacing: -0.7px; }
.close-button { flex: 0 0 44px; height: 44px; border: 1px solid #000; border-radius: 50%; background: #fff; color: #000; font-size: 26px; cursor: pointer; }
form { padding: 24px; }
fieldset { display: grid; gap: 20px; min-width: 0; margin: 0; padding: 0; border: 0; }
label { display: grid; gap: 8px; font-size: 13px; font-weight: 600; }
input, textarea, select { width: 100%; min-width: 0; box-sizing: border-box; padding: 12px 14px; border: 1px solid #000; border-radius: 10px; background: #fff; color: #000; font: inherit; font-size: 16px; font-weight: 400; }
textarea { resize: vertical; min-height: 110px; }
textarea::placeholder { color: #000; opacity: 1; }
footer { display: flex; flex-wrap: wrap; justify-content: flex-end; gap: 10px; margin-top: 28px; }
.button { min-height: 44px; padding: 10px 18px; border: 1px solid #000; border-radius: 999px; background: #fff; color: #000; font: inherit; font-size: 13px; font-weight: 600; cursor: pointer; }
.button--primary { background: #000; color: #fff; }
:is(button, input, textarea, select):focus-visible { outline: 2px solid #000; outline-offset: 3px; }
button:disabled, fieldset:disabled { opacity: 0.55; }
button:disabled { cursor: wait; }
.form-error { margin: 20px 0 0; padding: 12px; border: 1px solid #000; border-radius: 8px; font-size: 13px; line-height: 1.6; overflow-wrap: anywhere; }
@media (max-width: 480px) { .edit-modal__header, form { padding: 20px; } footer .button { flex: 1 1 100%; } }
</style>
